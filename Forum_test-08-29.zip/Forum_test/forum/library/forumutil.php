<?php

/**
 * forumutil short summary.
 *
 * forumutil description.
 *
 * @version 1.0
 * @author C
 */
class ForumUtil
{
    static function Show(){echo "ssssss";} 
}
