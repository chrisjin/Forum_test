<?php

//define('DIR_APPLICATION', 'C:\Home\WorkPlace\PHPWorkplace\Forum_test\Forum_test\forum/');
//define('HTTP_SERVER', 'http://localhost:48797/');
//define('DIR_TEMPLATE', 'C:\Home\WorkPlace\PHPWorkplace\Forum_test\Forum_test\forum\view/');
//define('DIR_SYSTEM', 'C:\Home\WorkPlace\PHPWorkplace\Forum_test\Forum_test\system/');
//define('DIR_IMAGE',  'C:\Home\WorkPlace\PHPWorkplace\Forum_test\Forum_test\forum\view\img/');
//define('DIR_STYLE', 'C:\Home\WorkPlace\PHPWorkplace\Forum_test\Forum_test\forum\view\css/');

//define('DB_DATABASE', 'forum_test');
define('DB_DATABASE', 'forum_test');
define('HTTP_SERVER', 'http://localhost:48797/');


define('DIR_APPLICATION', './forum/');
define('DIR_TEMPLATE', './forum/view/');
define('DIR_SYSTEM', './system/');
define('DIR_IMAGE',  './forum/view/img/');
define('DIR_STYLE', './forum/view/css/');

define('PATH_FOOTER', 'footer.html');
define('PATH_HEADER', 'header.html');

define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_PREFIX', 'oc_');

define('CONTROLLER_HOME', 'common/home');
define('TIME_ZONE', 'America/New_York');

//cdfuserservice123
//cdfuserservice@gmail.com

define('EMAIL_ADDRESS', 'cdfuserservice@gmail.com');
define('EMAIL_HOST', 'smtp.gmail.com');
define('EMAIL_FROMNAME', 'CDF User Service');
define('EMAIL_PASSWORD', 'cdfuserservice123');
define('EMAIL_HOST_PORT', 587);
define('EMAIL_SECURE', 'tls');